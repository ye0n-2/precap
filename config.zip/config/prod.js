module.exports = {
    mongoURI: "mongodb+srv://kangji1101:jiyeon2885@cluster0.xptaeof.mongodb.net/?retryWrites=true&w=majority"
  }