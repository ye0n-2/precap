import sys
import torch
from PIL import Image
import torchvision.transforms as transforms
import json

# YOLOv5 모델 불러오기
sys.path.insert(0, 'C:/Users/광운MOOC센터/yolov5')
from yolov5.models.experimental import attempt_load
from yolov5.utils.general import non_max_suppression

#이미지 파일 경로
imagePath = sys.argv[1]

# 저장된 모델 불러오기
model_path = 'C:/train7_result/yolov5/runs/train/foodmanager7/weights/best.pt' # 저장된 모델의 경로
model = attempt_load(model_path, device='cpu')
model.eval() 

# 이미지 로드 및 전처리
image = Image.open(imagePath).convert('RGB')  # 이미지 로드 및 RGB로 변환
transform = transforms.Compose([
    transforms.Resize((640, 640)),  # YOLOv5로 설정한 이미지 크기로 변경
    transforms.ToTensor(),  # tensor로 변환
])

image = transform(image).unsqueeze(0) 

results = model(image)
results = non_max_suppression(results[0], 0.4, 0.5)  # 결과 처리

# 객체 정보 및 JSON 형식으로 결과 저장
detections = []
for det in results:
    if len(det):
        for *xyxy, conf, cls in det:
            xmin, ymin, xmax, ymax = [int(x.item()) for x in xyxy]
            confidence = conf.item()
            class_idx = int(cls.item())
            label = model.names[class_idx]
            detections.append({'label': label, 'confidence': confidence, 'bounding_box': (xmin, ymin, xmax, ymax)})

# JSON 형식으로 결과 저장 및 출력
output_path = 'C:\\Users\\광운MOOC센터\\Documents\\detected_image.json'
with open(output_path, 'w') as f:
    json.dump({'detections': detections}, f)

# JSON 데이터만 콘솔에 출력 (Node.js로 데이터 전송)
print(json.dumps({'detections': detections}))