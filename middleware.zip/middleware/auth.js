const { User } = require("../models/User");

let auth = (req, res, next) => {
    let token;

    // 클라이언트 쿠키에서 토큰 가져오기
    if (req.cookies.x_auth) {
        token = req.cookies.x_auth;
    }
    // 클라이언트 요청 헤더에서 토큰 가져오기
    else if (req.headers.authorization && req.headers.authorization.startsWith("Bearer ")) {
        token = req.headers.authorization.slice(7, req.headers.authorization.length);
    }

    // 토큰이 없는 경우
    if (!token) {
        console.log("토큰 없음");
        return res.status(401).json({
            isAuth: false, error: true, message: "토큰 미제공"
        });
    }

    // 토큰을 복호화한 후 일치하는 유저 찾기
    User.findByToken(token)
        .then((user) => {
            if (!user) {
                console.log("토큰 불일치");
                return res.status(401).json({
                    isAuth: false, error: true, message: "일치하지 않는 토큰"
                });
            }
            console.log("토큰 일치");
            req.token = token;
            req.user = user;
            next();
        })
        .catch((err) => {
            console.log("findByToken에서 에러발생", err);
            return res.status(500).json({
                isAuth: false, error: true, message: "서버 에러"
            });
        });
};

module.exports = { auth };

