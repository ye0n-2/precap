const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const userSchema = mongoose.Schema({
  name: {
    type: String,
    maxlength: 50,
  },
  high: {
    type: Number,
    maxlength: 3,
  },
  kg: {
    type: String,
    maxlength: 3,
  },
  gender: {
    type: String,
    maxlength: 50,
  },
  email: {
    type: String,
    trim: true,   //스페이스를 없애줌
    unique: 1,    //중복 허용하지 않음
  },
  password: {
    type: String,
    minlength: 5,
  },
  token: {
    type: String,
  },
  tokenExp: {
    type: Number,
  },
});

userSchema.pre("save", function (next) {
  const user = this;  //userSchema
  // 비밀번호가 변경되었을 때
  if (user.isModified('password')) {
    bcrypt.genSalt(10, function (err, salt) {
      if (err) return next(err);
      bcrypt.hash(user.password, salt, function (err, hash) {
        if (err) return next(err);
        user.password = hash;
        next();
      });
    });
  } else {
    next();
  }
});
// 비밀번호 비교
userSchema.methods.comparePassword = function (plainPassword) {
  return bcrypt
    .compare(plainPassword, this.password)
    .then((isMatch) => isMatch)
    .catch((err) => (err));
};
// 토큰 생성
userSchema.methods.generateToken = async function () {
  const user = this;
  try {
    // jsonwebtoken을 사용해서 토큰 생성
    const token = await jwt.sign(user._id.toHexString(), "createToken");
    if (!token) {
      throw new Error("토큰이 생성되지 않았습니다.");
    }
    this.token = token;

    await this.save()
    return user;
  } catch (error) {
    console.error("토큰 생성 중 에러:", error);
    throw error;
  }
};

userSchema.statics.findByToken = function (token) {
  const User=this;
  //토큰 decode
  //createToken을 통해 user의 _id값을 받아오고 해당 아이디를 통해
  //Db에서 유저 정보를 가져옴
return new Promise((resolve, reject) => {
    jwt.verify(token, "createToken", (err, decoded) => {
      if (err) return reject(err);
      console.log("--------------------------")
      console.log("토큰이 일치하는지 확인중");
      User
        .findOne({ _id: decoded, token: token })
        .then((foundUser) => resolve(foundUser))
        .catch((err) => reject(err));
    });
  });
};

const User = mongoose.model("User", userSchema);    //스키마를 모델로 감싸줌
module.exports = { User };